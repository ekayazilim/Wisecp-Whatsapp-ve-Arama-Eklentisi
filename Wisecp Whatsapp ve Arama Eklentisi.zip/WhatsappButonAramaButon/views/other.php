<p>This is another hidden page.</p>

<a href="<?php echo $link; ?>" class="lbtn"><i class="fa fa-arrow-left"></i> Back to Home</a>
