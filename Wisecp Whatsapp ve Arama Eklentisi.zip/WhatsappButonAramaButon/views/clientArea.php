<?php if ($phone_number): ?>
    <p><a href="<?php echo $whatsapp_link; ?>" class="lbtn" target="_blank">Whatsapp'tan Mesaj Gönder</a></p>
    <p><a href="<?php echo $call_link; ?>" class="lbtn">Arama Yap</a></p>
<?php else: ?>
    <p>Telefon numarası henüz ayarlanmamış.</p>
<?php endif; ?>
