<?php
return [
    'phone_number' => 'Telefon Numarası',
    'phone_number_description' => 'Alan kodu ile telefon numarasını girin',
    'module_name' => 'Whatsapp Buton ve Arama Buton',
    'error1' => 'Lütfen bir telefon numarası girin.',
];
