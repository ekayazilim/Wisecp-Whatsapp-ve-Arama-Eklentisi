<?php
return [
    'phone_number' => 'Phone Number',
    'phone_number_description' => 'Enter phone number with country code',
    'module_name' => 'Whatsapp Button and Call Button',
    'error1' => 'Please enter a phone number.',
];
