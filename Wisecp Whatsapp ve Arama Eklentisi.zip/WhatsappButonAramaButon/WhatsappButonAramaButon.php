<?php

class WhatsappButonAramaButon extends AddonModule {
    public $version = "1.0";

    function __construct() {
        $this->_name = __CLASS__;
        parent::__construct();
    }

    public function fields() {
        $settings = isset($this->config['settings']) ? $this->config['settings'] : [];
        return [
            'phone_number' => [
                'wrap_width'    => 100,
                'name'          => "Telefon Numarası",
                'description'   => "Alan kodu ile birlikte telefon numarasını giriniz",
                'type'          => "text",
                'value'         => isset($settings["phone_number"]) ? $settings["phone_number"] : "",
                'placeholder'   => "+905551234567",
            ],
            'whatsapp_button_text' => [
                'wrap_width'    => 100,
                'name'          => "Whatsapp Buton Yazısı",
                'description'   => "Whatsapp butonu üzerinde görünecek yazıyı giriniz",
                'type'          => "text",
                'value'         => isset($settings["whatsapp_button_text"]) ? $settings["whatsapp_button_text"] : "Mesaj Gönder",
                'placeholder'   => "Whatsapp'tan Mesaj Gönder",
            ],
            'whatsapp_message' => [
                'wrap_width'    => 100,
                'name'          => "Whatsapp Mesajı",
                'description'   => "Kullanıcı Whatsapp butonuna tıkladığında otomatik olarak gönderilecek mesajı giriniz.",
                'type'          => "textarea",
                'value'         => isset($settings["whatsapp_message"]) ? $settings["whatsapp_message"] : "Merhaba, daha fazla bilgi almak istiyorum.",
                'placeholder'   => "Mesajınızı buraya girin",
            ],
            'call_button_text' => [
                'wrap_width'    => 100,
                'name'          => "Arama Buton Yazısı",
                'description'   => "Arama butonu üzerinde görünecek yazıyı giriniz",
                'type'          => "text",
                'value'         => isset($settings["call_button_text"]) ? $settings["call_button_text"] : "Arama Yap",
                'placeholder'   => "Arama Yap",
            ],
        ];
    }

    public function save_fields($fields = []) {
        if (!isset($fields['phone_number']) || !$fields['phone_number']) {
            $this->error = $this->lang["error1"];
            return false;
        }
        return $fields;
    }

    public function activate() {
        return true;
    }

    public function deactivate() {
        return true;
    }

    public function adminArea() {
        $action = Filter::init("REQUEST/action", "route");
        if (!$action) $action = 'index';

        $variables = [
            'link'          => $this->area_link,
            'dir_link'      => $this->url,
            'dir_path'      => $this->dir,
            'dir_name'      => $this->_name,
            'name'          => "Whatsapp Buton ve Arama Buton",
            'version'       => $this->version,
            'fields'        => $this->fields(),
        ];

        return [
            'page_title'    => 'Whatsapp Buton ve Arama Buton Modülü',
            'breadcrumbs'   => [
                [
                    'link'      => '',
                    'title'     => 'Whatsapp Buton ve Arama Buton',
                ],
            ],
            'content'       => $this->view($action . ".php", $variables)
        ];
    }

    public function upgrade() {
        if ($this->config["meta"]["version"] < 1.1) {
            
        }
        return true;
    }
}
Hook::add("ClientAreaHeadCSS", 1, function () {
    return '<style>
        /* Mobilde butonları gizlemek için */
        .desktop-buttons {
            display: none;
        }

        /* Mobil Cihazlar İçin */
        @media only screen and (max-width: 768px) {
            .desktop-buttons {
                display: none;
            }

            #mobil-fix {
                position: fixed;
                bottom: 0;
                width: 100%;
                display: flex;
                justify-content: space-around;
                background-color: #fff;
                z-index: 9999;
                box-shadow: 0px -2px 10px rgba(0, 0, 0, 0.1);
            }

            #mobil-fix a {
                display: flex;
                align-items: center;
                justify-content: center;
                width: 50%;
                padding: 15px;
                font-size: 14px;
                font-weight: bold;
                color: #fff;
                text-align: center;
                text-decoration: none;
            }

            #mobil-fix a:first-child {
                background-color: #34b7f1; /* Mavi renk */
            }

            #mobil-fix a:last-child {
                background-color: #25d366; /* Whatsapp yeşili */
            }

            #mobil-fix i {
                margin-right: 8px;
                font-size: 22px;
            }
        }

        @media only screen and (min-width: 769px) {
            .desktop-buttons {
                position: fixed;
                bottom: 20px;
                left: 20px;
                z-index: 9999;
                display: flex;
                flex-direction: column;
            }
            .desktop-buttons .whatsapp-button, .desktop-buttons .call-button {
                margin: 10px 0;
                padding: 10px 20px;
                color: #fff;
                background-color: #25d366; /* Whatsapp yeşili */
                border-radius: 25px;
                text-align: center;
                text-decoration: none;
                font-size: 16px;
                font-weight: bold;
                box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            }
            .desktop-buttons .call-button {
                background-color: #34b7f1; /* Mavi renk */
            }
            .desktop-buttons .whatsapp-button i, .desktop-buttons .call-button i {
                margin-right: 8px;
            }

            #mobil-fix {
                display: none; /* Masaüstü cihazlarda gizle */
            }
        }
    </style>';
});

Hook::add("ClientAreaBeginBody", 1, function () {
    $config = Modules::Config("Addons", "WhatsappButonAramaButon");
    $phone_number = $config['settings']['phone_number'];
    $whatsapp_button_text = isset($config['settings']['whatsapp_button_text']) ? $config['settings']['whatsapp_button_text'] : 'Mesaj Gönder';
    $call_button_text = isset($config['settings']['call_button_text']) ? $config['settings']['call_button_text'] : 'Arama Yap';
    $whatsapp_message = isset($config['settings']['whatsapp_message']) ? urlencode($config['settings']['whatsapp_message']) : '';

    if ($phone_number) {
        $whatsapp_link = "https://wa.me/" . preg_replace('/[^0-9]/', '', $phone_number) . "?text=" . $whatsapp_message;
        $call_link = "tel:" . preg_replace('/[^0-9]/', '', $phone_number);
        
        return '<div id="mobil-fix">
            <a href="' . $call_link . '">
                <span class="animate__animated animate__pulse animate__infinite">
                    <i class="fa fa-phone"></i> ' . $call_button_text . '
                </span>
            </a>
            <a href="' . $whatsapp_link . '" style="font-size:15px">
                <span class="animate__animated animate__pulse animate__infinite" style="display: flex; align-items: center;">
                    <i class="fa fa-whatsapp" style="font-size: 22px;"></i> ' . $whatsapp_button_text . '
                </span>
            </a>
        </div>
        <div class="desktop-buttons">
            <a href="' . $whatsapp_link . '" class="whatsapp-button" target="_blank"><i class="fa fa-whatsapp"></i> ' . $whatsapp_button_text . '</a>
            <a href="' . $call_link . '" class="call-button"><i class="fa fa-phone"></i> ' . $call_button_text . '</a>
        </div>';
    }
});
