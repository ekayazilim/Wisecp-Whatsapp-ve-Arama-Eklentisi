<?php 
return [
    'created_at'         => 1723387367,
    'meta'               => [
        'name'         => 'Whatsapp ve Arama Butonu',
        'version'      => '1.0',
        'author'       => "Eka Yaz\xc4\xb1l\xc4\xb1m",
        'opening-type' => 'normal',
    ],
    'show_on_adminArea'  => true,
    'show_on_clientArea' => true,
    'status'             => true,
    'access_ps'          => ['1'],
    'settings'           => [
        'phone_number'          => '+908503073458',
        'button_text'           => "Mesaj G\xc3\xb6nder",
        'whatsapp_message'      => 'Merhaba, daha fazla bilgi almak istiyorum.',
        'whatsapp_button_text'  => "Mesaj G\xc3\xb6nder       ",
        'call_button_text'      => 'Arama Yap',
        'whatsapp_button_color' => '#25d366',
        'call_button_color'     => '#34b7f1',
        'enable_on_mobile'      => '1',
    ],
];
